from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session

import models, schemas
from database import SessionLocal, engine

models.Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

app = FastAPI(title="KPA Form API", version="1.0.0")

@app.post("/form", response_model=schemas.FormResponse, status_code=201)
def create_form(form: schemas.FormCreate, db: Session = Depends(get_db)):
    db_form = models.Form(**form.dict())
    db.add(db_form)
    db.commit()
    db.refresh(db_form)
    return db_form

@app.get("/form/{form_id}", response_model=schemas.FormResponse)
def read_form(form_id: int, db: Session = Depends(get_db)):
    form = db.query(models.Form).filter(models.Form.id == form_id).first()
    if not form:
        raise HTTPException(status_code=404, detail="Form not found")
    return form
