# KPA Backend Assignment – Form API

This is a simple backend API built using **FastAPI** and **SQLite** to store and retrieve form data.

---

## 📦 Project Structure

